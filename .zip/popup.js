document.addEventListener('DOMContentLoaded', function() {
    // Your popup.js code here
});